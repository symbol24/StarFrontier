﻿using UnityEngine;
using System.Collections;

public class CannonReferences : MonoBehaviour {
	public string m_name;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
